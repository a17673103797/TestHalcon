﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test22
{
    public partial class Form1 : Form
    {
        getHotJian gethot = new getHotJian();
        ConnectToMySql contomysql = new ConnectToMySql();

        public Form1()
        {
            InitializeComponent();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            
            gethot.ShowDialog();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            contomysql.ShowDialog();
        }
    }
}
