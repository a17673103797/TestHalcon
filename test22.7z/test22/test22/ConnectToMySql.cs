﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data;
using System.Diagnostics;

namespace test22
{
    public partial class ConnectToMySql : Form
    {

        private MySqlConnection mysql;
        String server,port, user, passwd, database;
        
        




        public ConnectToMySql()
        {
            InitializeComponent();
        }

        //数据库连接
        //只需要登陆一次，将返回的对象传入下面的函数即可
        public MySqlConnection connetion(string server, string port, string user, string passwd, string database)
        {   /*
            String conStr = string.Format("server={0};port={1}user id={2};password={3};database={4}", server, port,user, passwd, database);
            MySqlConnection DBcon = new MySqlConnection(conStr);
            //DBcon.ConnectionString = conStr;
            DBcon.Open();
             * string M_str_sqlcon = "server=cdb-p64rh8th.gz.tencentcdb.com;port=10065;user id=root;password=Aa8812508;database=MyTest";
             * string server, string port,string user, string passwd, string database
            **/

            //构建数据库连接字符串
            string M_str_sqlcon = "server=" + server + ";port=" + port + ";user id=" + user + ";password=" + passwd + ";database=" + database; //根据自己的设置
            //创建数据库连接对象
            MySqlConnection mycon = new MySqlConnection();
            mycon.ConnectionString = M_str_sqlcon;
            return mycon;
        }

        //数据库操作
        //不需要额外调用
        public MySqlCommand command(string sql, MySqlConnection DBconn)
        {
            MySqlCommand rt = new MySqlCommand(sql, DBconn);
            return rt;
        }

        //数据库增删改
        public int Exute(string sql, MySqlConnection DBconn)
        {
            //返回受影响的行数
            return this.command(sql, DBconn).ExecuteNonQuery();
        }

        //通过select语句进行查询
        public MySqlDataReader read(string sql, MySqlConnection DBconn)
        {
            //数据库查询
            return this.command(sql, DBconn).ExecuteReader();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox7.Text != ""&&textBox8.Text!="")
            {
                server = textBox1.Text;
                port = textBox8.Text;
                user = textBox2.Text;
                passwd = textBox3.Text;
                database = textBox7.Text;
                try
                {
                    mysql = connetion(server,port,user,passwd,database);
                    if (mysql != null)
                    {
                        //打开数据库连接
                        mysql.Open();
                        label9.Text = "数据库已连接！";
                    }
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message);
                    Debug.Write(ex);
                    richTextBox1.Text = ex.ToString();
                    MessageBox.Show("请输入正确的数据库信息！", "提示", MessageBoxButtons.OK);//消息提示框。用于提示信息；
                }
            }
            else {
                MessageBox.Show("请输入数据库信息！", "提示", MessageBoxButtons.OK);//消息提示框。用于提示信息；
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = null;
            if (textBox6.Text != "")
            {
                try
                {
                    string sql = "select * from " + textBox6.Text;
                    MySqlDataAdapter mda = new MySqlDataAdapter(sql, mysql);
                    DataSet ds = new DataSet();
                    mda.Fill(ds, "table1");
                    //显示数据

                    this.dataGridView1.DataSource = ds.Tables["table1"];
                    // Test(dataGridView1);
                }
                catch (Exception ex)
                {
                    Debug.Write(ex);
                    richTextBox1.AppendText(ex.ToString());
                    richTextBox1.ForeColor = Color.Red;
                    MessageBox.Show("请输入正确的表名称信息！", "提示", MessageBoxButtons.OK);//消息提示框。用于提示信息；
                }
                
            }
            else {
                MessageBox.Show("请输入正确的表名称信息！", "提示", MessageBoxButtons.OK);//消息提示框。用于提示信息；
            }
           
        }

        private void ConnectToMySql_Load(object sender, EventArgs e)
        {
            textBox1.Text = "cdb-p64rh8th.gz.tencentcdb.com";
            textBox2.Text = "root";
            textBox3.Text = "Aa8812508";
            textBox6.Text = "user";
            textBox7.Text = "MyTest";
            textBox8.Text = "10065";

        }

        public static void Test(DataGridView dataGridView1)
        {
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                if (dataGridView1.Columns[i].HeaderCell.Value.ToString() == "第一列")
                {
                    dataGridView1.Columns[i].Width = 30;
                    dataGridView1.Columns[i].Resizable = DataGridViewTriState.False;
                    break;
                }
            }

        }


        //用于判断使用，只有两种结果：true or false?
        bool bool1,
             bool2;//false

        //字符、以及字符串的操作变量类型
        string name="张三", pwd="123456";
        char y, x;

        //“数字”操作变量类型
        int i = 1999999999, b = 2;
        byte num = 11;
        short o = 1, p = 2;
        long lon1 = 1456700099999999, lon2 = 8227;
        double dou = 9999.888;

        private void button5_Click(object sender, EventArgs e)
        {
            dou = lon1+0.66;
            richTextBox1.Text="name:"+name+"pwd:"
                +pwd+"\n"+"i:"+i+"b:"+b+"\n"+"dou:"+dou+"long1+"+lon1;
        }

    }

}
